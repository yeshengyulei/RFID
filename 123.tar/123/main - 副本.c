#include<reg51.h>

unsigned char code PuZh[] = {0x03, 0x08, 0xC1, 0x20, 0x08, 0x00, 0x00, 0x1E};
unsigned char code baozhan00001[] = {0xAA, 0x07, 0x02, 0x00, 0x0C, 0xBF };
unsigned char UartRxDataFlag = 0x00; 
unsigned char RxDataCount = 0x0;
#define UART_RX_BUF_LEN 30	
unsigned char xdata UartRxBuf[UART_RX_BUF_LEN];	//���ڻ�������С
#define MIN_PKT_LEN      8   //���������ŵ����ݰ�����Ϊ12�ֽ�
#define MAX_PKT_LEN      28		//����������+ָ�����ݿ�����ݰ�����Ϊ28�ֽ�
unsigned char buf[MAX_PKT_LEN];
unsigned char CardData[UART_RX_BUF_LEN];	
unsigned char j;

void UsartConfiguration();
void Delay10ms(unsigned int c);
void Out_Data (unsigned char Data[]);
void ProcessUartRxData(void);

void main()
{
        UsartConfiguration();
        Delay10ms(100);
        Out_Data(PuZh);
        for(i=0;i<UART_RX_BUF_LEN;i++)
	        UartRxBuf[i] = 0;
        while(1)
        {
                void ProcessUartRxData(void)
                Delay10ms(100);
        }
}

void UsartConfiguration()
{
        SCON=0X50;
        TMOD=0X20;
        PCON=0X80;
        TH1=0XFA;
        TL1=0XFA;
        TR1=1;
}

void Delay10ms(unsigned int c)
{
    unsigned char a, b;
    for (;c>0;c--)
        {
                for (b=38;b>0;b--)
                {
                        for (a=130;a>0;a--);
                }         
        }      
}

void Out_Data (unsigned char Data[])
{       
        j =  sizeof(Data);
        unsigned char i;
        for (i=0;i<j;i++)//
        {
                SBUF = Data[i];
                while (!TI);
                TI = 0;
        }
}

void UART() interrupt 4  //�����ж�
{
        ES = 0;
	if(RI)	//����Ƿ������� ��Ӳ������һ������ʱ RI ��λ
	{
                RI = 0;
                if(UartRxDataFlag == 0x00)
                {
                        UartRxBuf[RxDataCount] = SBUF;
                        RxDataCount++;
                        if(RxDataCount >= UART_RX_BUF_LEN)
                        {
                                RxDataCount = UART_RX_BUF_LEN - 1;
                        }
                        if ((UartRxBuf[1] == RxDataCount)&&(UartRxBuf[1] >= MIN_PKT_LEN)&&(UartRxBuf[1] <= MAX_PKT_LEN))
                        {
                                UartRxDataFlag = 0x01;
                                RxDataCount = 0x00;
                        }
                        else if ((UartRxBuf[1]<MIN_PKT_LEN)&&(UartRxBuf[1] > MAX_PKT_LEN))
                        {
                                RxDataCount = 0x00;
                        }
                }
	}
}


void ProcessUartRxData(void)
{
        unsigned char check;
	unsigned char pktlen;
	unsigned char i;
        if(UartRxDataFlag)
        {
                pktlen  = UartRxBuf[1];
                for(i=0;i<pktlen;i++)
                {
                        buf[i] = UartRxBuf[I];
                }
                UartRxDataFlag = 0x00;
                if((buf[0] == 0x04)&&(buf[1] == 0x16)&&(buf[2] == 0x03)&&(buf[3] == 0x20)&&(buf[4] ==0x00))
                {
                        for(i = 0; i < 16 ; i++)
                        {
                                CardData[i] = buf[(5+i)];
                        }
                        if((CardData[0]==0x62)&&(CardData[1] == 0x72)&&(CardData[2] == 0x74)&&(CardData[3]==0x00)&&(CardData[4] == 0x01))
                        {
                                Out_Data(baozhan00001);
                        }
                        return;

                }
	for(i=0;i<UART_RX_BUF_LEN;i++)	//��մ��ڻ�����
		UartRxBuf[i] = 0x00;                 
        }
}